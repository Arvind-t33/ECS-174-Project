# Self-Driving Cars > Version 4 - Prescan - 416x416
https://universe.roboflow.com/selfdriving-car-qtywx/self-driving-cars-lfjou

Provided by a Roboflow user
License: CC BY 4.0

